// Definición de la clase persona
class Persona {
    private String nombre;
    private int edad;
    private String ocupacion;

    public Persona(String nombre, int edad, String ocupacion) {
        this.nombre = nombre;
        this.edad = edad;
        this.ocupacion = ocupacion;
    }

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Ocupación: " + ocupacion);
    }

    public void actualizarOcupacion(String nuevaOcupacion) {
        this.ocupacion = nuevaOcupacion;
        System.out.println("La ocupación ha sido actualizada a: " + ocupacion);
    }

    public void mostrarRol() {
        System.out.println("Esta persona tiene un rol genérico.");
    }
}

// Definición de la clase estudiante
class Estudiante extends Persona {
    public Estudiante(String nombre, int edad, String ocupacion) {
        super(nombre, edad, ocupacion);
    }

    @Override
    public void mostrarRol() {
        System.out.println("Este estudiante está matriculado en la universidad.");
    }
}

// Definición de la clase docente
class Docente extends Persona {
    public Docente(String nombre, int edad, String ocupacion) {
        super(nombre, edad, ocupacion);
    }

    @Override
    public void mostrarRol() {
        System.out.println("Este docente da clases en la universidad.");
    }
}

// Definición de la clase administrativo
class Administrativo extends Persona {
    public Administrativo(String nombre, int edad, String ocupacion) {
        super(nombre, edad, ocupacion);
    }

    @Override
    public void mostrarRol() {
        System.out.println("Este administrativo trabaja en la parte administrativa de la universidad.");
    }
}

// Definición de la clase ObjetosDePersona
public class ObjetosDePersona {
    public static void main(String[] args) {
        Persona estudiante = new Estudiante("Santiago", 20, "Estudiante de Ingeniería");
        Persona docente = new Docente("Diego Iván", 30, "Profesor de Lenguajes de programación");
        Persona administrativo = new Administrativo("Carlos", 40, "Secretario Administrativo");

        estudiante.mostrarInformacion();
        estudiante.actualizarOcupacion("Estudiante de Medicina");
        estudiante.mostrarRol();

        docente.mostrarInformacion();
        docente.actualizarOcupacion("Profesora de Física");
        docente.mostrarRol();

        administrativo.mostrarInformacion();
        administrativo.actualizarOcupacion("Asistente Administrativo");
        administrativo.mostrarRol();
    }
}
